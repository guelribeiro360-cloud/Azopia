package com.meulauncher.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

public class MainActivity extends Activity {

    private static final int REQ_PICK_FILE = 42;
    private static final int REQ_PICK_IMAGE = 43;
    private static final int REQ_BACKUP_SAVE = 44;
    private static final int REQ_BACKUP_LOAD = 45;

    private WebView web;
    private String pendingBackup = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setBackgroundDrawable(new ColorDrawable(0xFF140609));

        web = new WebView(this);
        web.setBackgroundColor(0xFF140609);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme())) {
                    return false;
                }
                // Links de jogos abrem no navegador do tablet
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        web.loadUrl("file:///android_asset/index.html");
        hideBars();
    }

    private void hideBars() {
        web.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideBars();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        callJs("window.onAppPause && window.onAppPause()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            hideBars();
        }
        callJs("window.onAppResume && window.onAppResume()");
    }

    // Tela inicial não deve fechar com o botão voltar
    @Override
    public void onBackPressed() {
    }

    private void callJs(final String js) {
        if (web == null) {
            return;
        }
        web.post(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript(js, null);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            if (requestCode == REQ_BACKUP_SAVE) {
                callJs("window.onBackupSaved && window.onBackupSaved(false)");
            }
            return;
        }
        Uri uri = data.getData();
        if (requestCode == REQ_PICK_FILE) {
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            callJs("window.onFilePicked && window.onFilePicked("
                    + JSONObject.quote(uri.toString()) + "," + JSONObject.quote(displayName(uri)) + ")");
        } else if (requestCode == REQ_PICK_IMAGE) {
            handleImage(uri);
        } else if (requestCode == REQ_BACKUP_SAVE) {
            boolean ok = false;
            try {
                OutputStream os = getContentResolver().openOutputStream(uri, "w");
                os.write(pendingBackup.getBytes("UTF-8"));
                os.close();
                ok = true;
            } catch (Exception ignored) {
            }
            callJs("window.onBackupSaved && window.onBackupSaved(" + ok + ")");
        } else if (requestCode == REQ_BACKUP_LOAD) {
            try {
                InputStream in = getContentResolver().openInputStream(uri);
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] chunk = new byte[8192];
                int n;
                while ((n = in.read(chunk)) > 0) {
                    buf.write(chunk, 0, n);
                    if (buf.size() > 8 * 1024 * 1024) {
                        break;
                    }
                }
                in.close();
                String text = new String(buf.toByteArray(), "UTF-8");
                callJs("window.onBackupLoaded && window.onBackupLoaded(" + JSONObject.quote(text) + ")");
            } catch (Exception e) {
                callJs("window.onBackupLoaded && window.onBackupLoaded('')");
            }
        }
    }

    /** Reduz a imagem escolhida para 120x160 (corte central) e devolve como data URI. */
    private void handleImage(Uri uri) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            InputStream in = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in, null, bounds);
            in.close();

            int sample = 1;
            while (bounds.outWidth / (sample * 2) >= 240 && bounds.outHeight / (sample * 2) >= 320) {
                sample *= 2;
            }
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            in = getContentResolver().openInputStream(uri);
            Bitmap src = BitmapFactory.decodeStream(in, null, opts);
            in.close();
            if (src == null) {
                return;
            }

            int w = 120;
            int h = 160;
            float r = Math.max(w / (float) src.getWidth(), h / (float) src.getHeight());
            int sw = Math.max(w, Math.round(src.getWidth() * r));
            int sh = Math.max(h, Math.round(src.getHeight() * r));
            Bitmap scaled = Bitmap.createScaledBitmap(src, sw, sh, true);
            Bitmap out = Bitmap.createBitmap(scaled, (sw - w) / 2, (sh - h) / 2, w, h);

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            out.compress(Bitmap.CompressFormat.JPEG, 85, bos);
            String data = "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
            callJs("window.onImagePicked && window.onImagePicked(" + JSONObject.quote(data) + ")");
        } catch (Exception ignored) {
        }
    }

    private String displayName(Uri uri) {
        String name = null;
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) {
                    name = c.getString(i);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) {
                c.close();
            }
        }
        if (name == null) {
            name = uri.getLastPathSegment();
        }
        return name == null ? "arquivo" : name;
    }

    private void openPicker(String action, String type, int code) {
        Intent i = new Intent(action);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type);
        startActivityForResult(i, code);
    }

    /** Ponte entre a página e o Android. */
    private class Bridge {

        @JavascriptInterface
        public String listApps() {
            JSONArray out = new JSONArray();
            try {
                PackageManager pm = getPackageManager();
                Intent main = new Intent(Intent.ACTION_MAIN);
                main.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
                for (ResolveInfo ri : list) {
                    String pkg = ri.activityInfo.packageName;
                    if (pkg.equals(getPackageName())) {
                        continue;
                    }
                    JSONObject o = new JSONObject();
                    o.put("label", ri.loadLabel(pm).toString());
                    o.put("pkg", pkg);
                    out.put(o);
                }
            } catch (Exception ignored) {
            }
            return out.toString();
        }

        @JavascriptInterface
        public boolean launchApp(final String pkg) {
            final Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) {
                return false;
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    startActivity(i);
                }
            });
            return true;
        }

        @JavascriptInterface
        public void setLandscape(final boolean on) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    setRequestedOrientation(on
                            ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                            : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                }
            });
        }

        @JavascriptInterface
        public void pickFile() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openPicker(Intent.ACTION_OPEN_DOCUMENT, "*/*", REQ_PICK_FILE);
                }
            });
        }

        @JavascriptInterface
        public void pickImage() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openPicker(Intent.ACTION_OPEN_DOCUMENT, "image/*", REQ_PICK_IMAGE);
                }
            });
        }

        @JavascriptInterface
        public void exportBackup(final String json) {
            pendingBackup = json == null ? "" : json;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/json");
                    i.putExtra(Intent.EXTRA_TITLE, "meu-launcher-backup.json");
                    startActivityForResult(i, REQ_BACKUP_SAVE);
                }
            });
        }

        @JavascriptInterface
        public void importBackup() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openPicker(Intent.ACTION_OPEN_DOCUMENT, "*/*", REQ_BACKUP_LOAD);
                }
            });
        }

        @JavascriptInterface
        public boolean openFile(final String uriText) {
            try {
                Uri uri = Uri.parse(uriText);
                String mime = getContentResolver().getType(uri);
                Intent view = new Intent(Intent.ACTION_VIEW);
                view.setDataAndType(uri, mime != null ? mime : "*/*");
                view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                final Intent chooser = Intent.createChooser(view, "Abrir com");
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            startActivity(chooser);
                        } catch (Exception ignored) {
                        }
                    }
                });
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void openHomeSettings() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
                    } catch (Exception e) {
                        startActivity(new Intent(Settings.ACTION_SETTINGS));
                    }
                }
            });
        }

        @JavascriptInterface
        public void openSystemSettings() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(new Intent(Settings.ACTION_SETTINGS));
                    } catch (Exception ignored) {
                    }
                }
            });
        }
    }
}
