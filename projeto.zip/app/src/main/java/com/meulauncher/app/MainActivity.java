package com.meulauncher.app;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.ExifInterface;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final int REQ_PICK_FILE = 42;
    private static final int REQ_PICK_IMAGE = 43;
    private static final int REQ_BACKUP_SAVE = 44;
    private static final int REQ_BACKUP_LOAD = 45;
    private static final int REQ_PICK_WALL = 46;
    private static final int REQ_PICK_STICKER = 47;

    private WebView web;
    private String pendingBackup = "";
    private MediaPlayer musicPlayer;
    private boolean resumeMusic = false;
    private final ExecutorService imageExecutor = Executors.newSingleThreadExecutor();
    private static final int REQ_PICK_MUSIC = 48;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setBackgroundDrawable(new ColorDrawable(0xFF0D111C));

        web = new WebView(this);
        web.setBackgroundColor(0xFF0D111C);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String url = uri.toString();
                if (url.startsWith("file:///android_asset/")) return false;
                if ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                }
                return true;
            }
        });

        web.loadUrl("file:///android_asset/index.html");
        hideBars();
    }

    private void hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideBars();
        }
    }

    @Override
    protected void onPause() {
        callJs("if(window.onAppPause)window.onAppPause();");
        if (musicPlayer != null && musicPlayer.isPlaying()) {
            resumeMusic = true;
            musicPlayer.pause();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            hideBars();
        }
        callJs("if(window.onAppResume)window.onAppResume();");
        if (resumeMusic && musicPlayer != null) {
            try { musicPlayer.start(); } catch (Exception ignored) {}
            resumeMusic = false;
        }
    }

    // Tela inicial não deve fechar com o botão voltar
    @Override
    public void onBackPressed() {
        callJs("(function(){if(document.querySelector('dialog[open]'))closeModal();})();");
    }

    private void callJs(final String js) {
        if (web == null) {
            return;
        }
        web.post(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript(js, null);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            if (requestCode == REQ_BACKUP_SAVE) callJs("if(window.onBackupSaved)window.onBackupSaved(false);");
            if (requestCode == REQ_BACKUP_LOAD) callJs("if(window.onBackupLoaded)window.onBackupLoaded('');");
            if (requestCode == REQ_PICK_MUSIC) callJs("if(window.onMusicPicked)window.onMusicPicked('', '');");
            if (requestCode == REQ_PICK_IMAGE) callJs("if(window.onImagePicked)window.onImagePicked('');");
            if (requestCode == REQ_PICK_WALL) callJs("if(window.onWallPicked)window.onWallPicked('');");
            if (requestCode == REQ_PICK_STICKER) callJs("if(window.onStickerPicked)window.onStickerPicked('');");
            return;
        }
        Uri uri = data.getData();
        if (requestCode == REQ_PICK_FILE) {
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            callJs("window.onFilePicked && window.onFilePicked("
                    + JSONObject.quote(uri.toString()) + "," + JSONObject.quote(displayName(uri)) + ")");
        } else if (requestCode == REQ_PICK_IMAGE) {
            imageExecutor.execute(() -> handleImage(uri, 120, 160, 85, "onImagePicked"));
        } else if (requestCode == REQ_PICK_WALL) {
            imageExecutor.execute(() -> handleImage(uri, 1600, 900, 78, "onWallPicked"));
        } else if (requestCode == REQ_PICK_STICKER) {
            imageExecutor.execute(() -> handleSticker(uri, 560, "onStickerPicked"));
        } else if (requestCode == REQ_PICK_MUSIC) {
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            callJs("if(window.onMusicPicked)window.onMusicPicked(" + JSONObject.quote(uri.toString()) + "," + JSONObject.quote(displayName(uri)) + ");");
        } else if (requestCode == REQ_BACKUP_SAVE) {
            boolean ok = false;
            try {
                OutputStream os = getContentResolver().openOutputStream(uri, "w");
                os.write(pendingBackup.getBytes("UTF-8"));
                os.close();
                ok = true;
            } catch (Exception ignored) {
            }
            callJs("window.onBackupSaved && window.onBackupSaved(" + ok + ")");
        } else if (requestCode == REQ_BACKUP_LOAD) {
            try {
                InputStream in = getContentResolver().openInputStream(uri);
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] chunk = new byte[8192];
                int n;
                while ((n = in.read(chunk)) > 0) {
                    buf.write(chunk, 0, n);
                    if (buf.size() > 12 * 1024 * 1024) {
                        break;
                    }
                }
                in.close();
                String text = new String(buf.toByteArray(), "UTF-8");
                callJs("window.onBackupLoaded && window.onBackupLoaded(" + JSONObject.quote(text) + ")");
            } catch (Exception e) {
                callJs("window.onBackupLoaded && window.onBackupLoaded('')");
            }
        }
    }

    /** Reduz a imagem escolhida para w x h (corte central) e devolve como data URI para a função JS indicada. */
    private void handleImage(Uri uri, int w, int h, int quality, String jsFn) {
        try {
            final boolean png = "onImagePicked".equals(jsFn) && isAlphaType(uri);
            if (png) {
                w *= 2;
                h *= 2;
            }
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            InputStream in = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in, null, bounds);
            in.close();

            int sample = 1;
            while (bounds.outWidth / (sample * 2) >= w && bounds.outHeight / (sample * 2) >= h) {
                sample *= 2;
            }
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            in = getContentResolver().openInputStream(uri);
            Bitmap src = BitmapFactory.decodeStream(in, null, opts);
            in.close();
            if (src == null) {
                callJs("if(window." + jsFn + ")window." + jsFn + "('');");
                return;
            }
            src = rotateExif(uri, src);

            Bitmap out;
            if (png) {
                // PNG: imagem inteira (sem cortar) sobre fundo transparente
                float r = Math.min(w / (float) src.getWidth(), h / (float) src.getHeight());
                int sw = Math.max(1, Math.round(src.getWidth() * r));
                int sh = Math.max(1, Math.round(src.getHeight() * r));
                Bitmap scaled = Bitmap.createScaledBitmap(src, sw, sh, true);
                out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                Canvas cv = new Canvas(out);
                cv.drawBitmap(scaled, (w - sw) / 2f, (h - sh) / 2f, null);
            } else {
                float r = Math.max(w / (float) src.getWidth(), h / (float) src.getHeight());
                int sw = Math.max(w, Math.round(src.getWidth() * r));
                int sh = Math.max(h, Math.round(src.getHeight() * r));
                Bitmap scaled = Bitmap.createScaledBitmap(src, sw, sh, true);
                out = Bitmap.createBitmap(scaled, (sw - w) / 2, (sh - h) / 2, w, h);
            }

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            if (png) {
                out.compress(Bitmap.CompressFormat.PNG, 100, bos);
            } else {
                out.compress(Bitmap.CompressFormat.JPEG, quality, bos);
            }
            String data = (png ? "data:image/png;base64," : "data:image/jpeg;base64,") + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
            callJs("window." + jsFn + " && window." + jsFn + "(" + JSONObject.quote(data) + ")");
        } catch (Exception ignored) {
        }
    }

    private Bitmap rotateExif(Uri uri, Bitmap bitmap) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) return bitmap;
            ExifInterface exif = new ExifInterface(in);
            int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            android.graphics.Matrix m = new android.graphics.Matrix();
            if (orientation == ExifInterface.ORIENTATION_ROTATE_90) m.postRotate(90);
            else if (orientation == ExifInterface.ORIENTATION_ROTATE_180) m.postRotate(180);
            else if (orientation == ExifInterface.ORIENTATION_ROTATE_270) m.postRotate(270);
            else if (orientation == ExifInterface.ORIENTATION_FLIP_HORIZONTAL) m.preScale(-1, 1);
            else if (orientation == ExifInterface.ORIENTATION_FLIP_VERTICAL) m.preScale(1, -1);
            else return bitmap;
            Bitmap rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), m, true);
            if (rotated != bitmap) bitmap.recycle();
            return rotated;
        } catch (Exception e) { return bitmap; }
    }

    private boolean isAlphaType(Uri uri) {
        String t = getContentResolver().getType(uri);
        if (t == null) {
            return false;
        }
        t = t.toLowerCase();
        return t.contains("png") || t.contains("webp") || t.contains("gif");
    }

    /** Imagem solta na tela: mantém a proporção (lado maior = max) e preserva a transparência do PNG. */
    private void handleSticker(Uri uri, int max, String jsFn) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            InputStream in = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in, null, bounds);
            in.close();

            int sample = 1;
            while (Math.max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= max) {
                sample *= 2;
            }
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
            in = getContentResolver().openInputStream(uri);
            Bitmap src = BitmapFactory.decodeStream(in, null, opts);
            in.close();
            if (src == null) {
                callJs("if(window." + jsFn + ")window." + jsFn + "('');");
                return;
            }
            src = rotateExif(uri, src);
            float r = Math.min(1f, max / (float) Math.max(src.getWidth(), src.getHeight()));
            Bitmap out = r < 1f
                    ? Bitmap.createScaledBitmap(src, Math.max(1, Math.round(src.getWidth() * r)), Math.max(1, Math.round(src.getHeight() * r)), true)
                    : src;
            boolean png = isAlphaType(uri) || out.hasAlpha();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            if (png) {
                out.compress(Bitmap.CompressFormat.PNG, 100, bos);
            } else {
                out.compress(Bitmap.CompressFormat.JPEG, 88, bos);
            }
            String data = (png ? "data:image/png;base64," : "data:image/jpeg;base64,") + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
            callJs("window." + jsFn + " && window." + jsFn + "(" + JSONObject.quote(data) + ")");
        } catch (Exception ignored) {
        }
    }

    private String displayName(Uri uri) {
        String name = null;
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) {
                    name = c.getString(i);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) {
                c.close();
            }
        }
        if (name == null) {
            name = uri.getLastPathSegment();
        }
        return name == null ? "arquivo" : name;
    }

    private void openPicker(String type, int code) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, code);
    }

    private void stopMusicInternal() {
        if (musicPlayer != null) {
            try { if (musicPlayer.isPlaying()) musicPlayer.stop(); } catch (Exception ignored) {}
            try { musicPlayer.release(); } catch (Exception ignored) {}
            musicPlayer = null;
        }
        resumeMusic = false;
    }

    @Override
    protected void onDestroy() {
        stopMusicInternal();
        imageExecutor.shutdown();
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    /** Ponte entre a página e o Android. */
    private class Bridge {

        @JavascriptInterface
        public String listApps() {
            JSONArray out = new JSONArray();
            try {
                PackageManager pm = getPackageManager();
                Intent main = new Intent(Intent.ACTION_MAIN);
                main.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
                Set<String> seen = new HashSet<String>();
                for (ResolveInfo ri : list) {
                    String pkg = ri.activityInfo.packageName;
                    if (pkg.equals(getPackageName()) || !seen.add(pkg)) {
                        continue;
                    }
                    ApplicationInfo ai = ri.activityInfo.applicationInfo;
                    boolean game = (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
                    if (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) {
                        game = true;
                    }
                    JSONObject o = new JSONObject();
                    o.put("label", ri.loadLabel(pm).toString());
                    o.put("pkg", pkg);
                    o.put("game", game);
                    out.put(o);
                }
            } catch (Exception ignored) {
            }
            return out.toString();
        }

        @JavascriptInterface
        public String getIcon(String pkg) {
            try {
                Drawable d = getPackageManager().getApplicationIcon(pkg);
                int s = 112;
                Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(bmp);
                d.setBounds(0, 0, s, s);
                d.draw(c);
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.PNG, 100, bos);
                return "data:image/png;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public boolean isInstalled(String pkg) {
            try {
                return getPackageManager().getLaunchIntentForPackage(pkg) != null;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public String getStatus() {
            JSONObject o = new JSONObject();
            try {
                Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                int bat = -1; boolean chg = false;
                if (b != null) {
                    int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                    int st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                    if (level >= 0 && scale > 0) bat = Math.round(level * 100f / scale);
                    chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
                }
                ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                Network n = cm == null ? null : cm.getActiveNetwork();
                NetworkCapabilities caps = (cm == null || n == null) ? null : cm.getNetworkCapabilities(n);
                boolean online = caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
                boolean wifi = caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                int cur = am.getStreamVolume(AudioManager.STREAM_MUSIC);
                float br = getWindow().getAttributes().screenBrightness;
                Integer bri = br < 0 ? null : Math.round(br * 100);
                o.put("online", online); o.put("wifi", wifi); o.put("bat", bat);
                o.put("chg", chg); o.put("vol", max > 0 ? Math.round(cur * 100f / max) : 0);
                if (bri == null) o.put("bri", JSONObject.NULL); else o.put("bri", bri);
            } catch (Exception ignored) {}
            return o.toString();
        }

        @JavascriptInterface
        public void setVolume(int pct) {
            try {
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(Math.max(0, Math.min(100, pct)) / 100f * max), 0);
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void setBrightness(final int pct) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    WindowManager.LayoutParams lp = getWindow().getAttributes();
                    lp.screenBrightness = Math.max(0f, Math.min(1f, pct / 100f));
                    getWindow().setAttributes(lp);
                }
            });
        }

        @JavascriptInterface
        public boolean launchApp(final String pkg) {
            final Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) {
                return false;
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            runOnUiThread(new Runnable() {
                @Override
                public void run() { try { startActivity(i); } catch (Exception ignored) {} }
            });
            return true;
        }

        @JavascriptInterface
        public void setLandscape(final boolean on) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    setRequestedOrientation(on
                            ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                            : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                }
            });
        }

        @JavascriptInterface
        public void pickFile() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openPicker("*/*", REQ_PICK_FILE);
                }
            });
        }

        @JavascriptInterface
        public void pickImage() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openPicker("image/*", REQ_PICK_IMAGE);
                }
            });
        }

        @JavascriptInterface
        public void pickSticker() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openPicker("image/*", REQ_PICK_STICKER);
                }
            });
        }
        @JavascriptInterface
        public void pickWallpaper() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openPicker("image/*", REQ_PICK_WALL);
                }
            });
        }

        @JavascriptInterface
        public void exportBackup(final String json) {
            pendingBackup = json == null ? "" : json;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/json");
                    i.putExtra(Intent.EXTRA_TITLE, "meu-launcher-backup.json");
                    startActivityForResult(i, REQ_BACKUP_SAVE);
                }
            });
        }

        @JavascriptInterface
        public void importBackup() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openPicker("*/*", REQ_BACKUP_LOAD);
                }
            });
        }

        @JavascriptInterface
        public boolean openFile(String uriText) { return openUri(uriText, null); }

        @JavascriptInterface
        public boolean openFileWith(String uriText, String pkg) { return openUri(uriText, pkg); }

        private boolean openUri(String uriText, String pkg) {
            try {
                Uri uri = Uri.parse(uriText);
                Intent view = new Intent(Intent.ACTION_VIEW);
                String mime = getContentResolver().getType(uri);
                view.setDataAndType(uri, mime == null ? "*/*" : mime);
                view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                if (pkg != null && !pkg.isEmpty()) view.setPackage(pkg);
                startActivity(view);
                return true;
            } catch (android.content.ActivityNotFoundException e) {
                return false;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface
        public void openHomeSettings() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
                    } catch (Exception e) {
                        startActivity(new Intent(Settings.ACTION_SETTINGS));
                    }
                }
            });
        }

        @JavascriptInterface
        public void openSystemSettings() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(new Intent(Settings.ACTION_SETTINGS));
                    } catch (Exception ignored) {
                    }
                }
            });
        }
        @JavascriptInterface
        public void pickMusic() {
            runOnUiThread(() -> openPicker("audio/*", REQ_PICK_MUSIC));
        }

        @JavascriptInterface
        public void playMusic(String uri, int volume) {
            runOnUiThread(() -> {
                stopMusicInternal();
                try {
                    musicPlayer = new MediaPlayer();
                    musicPlayer.setDataSource(MainActivity.this, Uri.parse(uri));
                    musicPlayer.setLooping(true);
                    float v = Math.max(0, Math.min(100, volume)) / 100f;
                    musicPlayer.setVolume(v, v);
                    musicPlayer.setOnPreparedListener(MediaPlayer::start);
                    musicPlayer.prepareAsync();
                } catch (Exception e) { stopMusicInternal(); }
            });
        }

        @JavascriptInterface
        public void stopMusic() { runOnUiThread(() -> stopMusicInternal()); }

        @JavascriptInterface
        public void openBluetooth() { openAction(Settings.ACTION_BLUETOOTH_SETTINGS); }

        @JavascriptInterface
        public void openWifiPanel() {
            runOnUiThread(() -> {
                try {
                    if (Build.VERSION.SDK_INT >= 29) startActivity(new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY));
                    else startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
                } catch (Exception ignored) { try { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); } catch (Exception ignored2) {} }
            });
        }

        private void openAction(String action) {
            runOnUiThread(() -> { try { startActivity(new Intent(action)); } catch (Exception ignored) {} });
        }

        @JavascriptInterface
        public String getDnd() {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 23 && !nm.isNotificationPolicyAccessGranted()) return "";
            return nm.getCurrentInterruptionFilter() == NotificationManager.INTERRUPTION_FILTER_ALL ? "off" : "on";
        }

        @JavascriptInterface
        public String toggleDnd() {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 23 && !nm.isNotificationPolicyAccessGranted()) {
                runOnUiThread(() -> { try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)); } catch (Exception ignored) {} });
                return "perm";
            }
            try {
                boolean currentlyOn = nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALL;
                nm.setInterruptionFilter(currentlyOn ? NotificationManager.INTERRUPTION_FILTER_ALL : NotificationManager.INTERRUPTION_FILTER_PRIORITY);
                return currentlyOn ? "off" : "on";
            } catch (Exception e) { return "perm"; }
        }

    }
}
