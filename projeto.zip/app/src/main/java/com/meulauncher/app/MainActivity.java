package com.meulauncher.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {

    private static final int REQ_PICK_FILE = 42;
    private static final int REQ_PICK_IMAGE = 43;
    private static final int REQ_BACKUP_SAVE = 44;
    private static final int REQ_BACKUP_LOAD = 45;
    private static final int REQ_PICK_WALL = 46;

    private WebView web;
    private String pendingBackup = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setBackgroundDrawable(new ColorDrawable(0xFF0D111C));

        web = new WebView(this);
        web.setBackgroundColor(0xFF0D111C);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme())) {
                    return false;
                }
                // Links de jogos abrem no navegador do tablet
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        web.loadUrl("file:///android_asset/index.html");
        hideBars();
    }

    private void hideBars() {
        web.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideBars();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        callJs("window.onAppPause && window.onAppPause()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            hideBars();
        }
        callJs("window.onAppResume && window.onAppResume()");
    }

    // Tela inicial não deve fechar com o botão voltar
    @Override
    public void onBackPressed() {
    }

    private void callJs(final String js) {
        if (web == null) {
            return;
        }
        web.post(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript(js, null);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            if (requestCode == REQ_BACKUP_SAVE) {
                callJs("window.onBackupSaved && window.onBackupSaved(false)");
            }
            return;
        }
        Uri uri = data.getData();
        if (requestCode == REQ_PICK_FILE) {
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            callJs("window.onFilePicked && window.onFilePicked("
                    + JSONObject.quote(uri.toString()) + "," + JSONObject.quote(displayName(uri)) + ")");
        } else if (requestCode == REQ_PICK_IMAGE) {
            handleImage(uri, 120, 160, 85, "onImagePicked");
        } else if (requestCode == REQ_PICK_WALL) {
            handleImage(uri, 1600, 900, 78, "onWallPicked");
        } else if (requestCode == REQ_BACKUP_SAVE) {
            boolean ok = false;
            try {
                OutputStream os = getContentResolver().openOutputStream(uri, "w");
                os.write(pendingBackup.getBytes("UTF-8"));
                os.close();
                ok = true;
            } catch (Exception ignored) {
            }
            callJs("window.onBackupSaved && window.onBackupSaved(" + ok + ")");
        } else if (requestCode == REQ_BACKUP_LOAD) {
            try {
                InputStream in = getContentResolver().openInputStream(uri);
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] chunk = new byte[8192];
                int n;
                while ((n = in.read(chunk)) > 0) {
                    buf.write(chunk, 0, n);
                    if (buf.size() > 12 * 1024 * 1024) {
                        break;
                    }
                }
                in.close();
                String text = new String(buf.toByteArray(), "UTF-8");
                callJs("window.onBackupLoaded && window.onBackupLoaded(" + JSONObject.quote(text) + ")");
            } catch (Exception e) {
                callJs("window.onBackupLoaded && window.onBackupLoaded('')");
            }
        }
    }

    /** Reduz a imagem escolhida para w x h (corte central) e devolve como data URI para a função JS indicada. */
    private void handleImage(Uri uri, int w, int h, int quality, String jsFn) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            InputStream in = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in, null, bounds);
            in.close();

            int sample = 1;
            while (bounds.outWidth / (sample * 2) >= w && bounds.outHeight / (sample * 2) >= h) {
                sample *= 2;
            }
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            in = getContentResolver().openInputStream(uri);
            Bitmap src = BitmapFactory.decodeStream(in, null, opts);
            in.close();
            if (src == null) {
                return;
            }

            float r = Math.max(w / (float) src.getWidth(), h / (float) src.getHeight());
            int sw = Math.max(w, Math.round(src.getWidth() * r));
            int sh = Math.max(h, Math.round(src.getHeight() * r));
            Bitmap scaled = Bitmap.createScaledBitmap(src, sw, sh, true);
            Bitmap out = Bitmap.createBitmap(scaled, (sw - w) / 2, (sh - h) / 2, w, h);

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            out.compress(Bitmap.CompressFormat.JPEG, quality, bos);
            String data = "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
            callJs("window." + jsFn + " && window." + jsFn + "(" + JSONObject.quote(data) + ")");
        } catch (Exception ignored) {
        }
    }

    private String displayName(Uri uri) {
        String name = null;
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) {
                    name = c.getString(i);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) {
                c.close();
            }
        }
        if (name == null) {
            name = uri.getLastPathSegment();
        }
        return name == null ? "arquivo" : name;
    }

    private void openPicker(String type, int code) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type);
        startActivityForResult(i, code);
    }

    /** Ponte entre a página e o Android. */
    private class Bridge {

        @JavascriptInterface
        public String listApps() {
            JSONArray out = new JSONArray();
            try {
                PackageManager pm = getPackageManager();
                Intent main = new Intent(Intent.ACTION_MAIN);
                main.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
                Set<String> seen = new HashSet<String>();
                for (ResolveInfo ri : list) {
                    String pkg = ri.activityInfo.packageName;
                    if (pkg.equals(getPackageName()) || !seen.add(pkg)) {
                        continue;
                    }
                    ApplicationInfo ai = ri.activityInfo.applicationInfo;
                    boolean game = (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
                    if (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) {
                        game = true;
                    }
                    JSONObject o = new JSONObject();
                    o.put("label", ri.loadLabel(pm).toString());
                    o.put("pkg", pkg);
                    o.put("game", game);
                    out.put(o);
                }
            } catch (Exception ignored) {
            }
            return out.toString();
        }

        @JavascriptInterface
        public String getIcon(String pkg) {
            try {
                Drawable d = getPackageManager().getApplicationIcon(pkg);
                int s = 96;
                Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(bmp);
                d.setBounds(0, 0, s, s);
                d.draw(c);
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.PNG, 100, bos);
                return "data:image/png;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public boolean isInstalled(String pkg) {
            try {
                return getPackageManager().getLaunchIntentForPackage(pkg) != null;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public String getStatus() {
            JSONObject o = new JSONObject();
            try {
                Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                if (b != null) {
                    int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                    int st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                    o.put("bat", scale > 0 ? level * 100 / scale : -1);
                    o.put("chg", st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL);
                }
                ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                Network n = cm.getActiveNetwork();
                NetworkCapabilities caps = n == null ? null : cm.getNetworkCapabilities(n);
                o.put("wifi", caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI));
                o.put("online", caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET));
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                int cur = am.getStreamVolume(AudioManager.STREAM_MUSIC);
                o.put("vol", max > 0 ? cur * 100 / max : 0);
                float br = getWindow().getAttributes().screenBrightness;
                if (br < 0) {
                    try {
                        br = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS) / 255f;
                    } catch (Exception e) {
                        br = 0.5f;
                    }
                }
                o.put("bri", Math.round(br * 100));
            } catch (Exception ignored) {
            }
            return o.toString();
        }

        @JavascriptInterface
        public void setVolume(int pct) {
            try {
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(Math.max(0, Math.min(100, pct)) / 100f * max), 0);
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void setBrightness(final int pct) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    WindowManager.LayoutParams lp = getWindow().getAttributes();
                    lp.screenBrightness = Math.max(0.02f, Math.min(1f, pct / 100f));
                    getWindow().setAttributes(lp);
                }
            });
        }

        @JavascriptInterface
        public boolean launchApp(final String pkg) {
            final Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) {
                return false;
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    startActivity(i);
                }
            });
            return true;
        }

        @JavascriptInterface
        public void setLandscape(final boolean on) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    setRequestedOrientation(on
                            ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                            : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                }
            });
        }

        @JavascriptInterface
        public void pickFile() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openPicker("*/*", REQ_PICK_FILE);
                }
            });
        }

        @JavascriptInterface
        public void pickImage() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openPicker("image/*", REQ_PICK_IMAGE);
                }
            });
        }

        @JavascriptInterface
        public void pickWallpaper() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openPicker("image/*", REQ_PICK_WALL);
                }
            });
        }

        @JavascriptInterface
        public void exportBackup(final String json) {
            pendingBackup = json == null ? "" : json;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/json");
                    i.putExtra(Intent.EXTRA_TITLE, "meu-launcher-backup.json");
                    startActivityForResult(i, REQ_BACKUP_SAVE);
                }
            });
        }

        @JavascriptInterface
        public void importBackup() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openPicker("*/*", REQ_BACKUP_LOAD);
                }
            });
        }

        @JavascriptInterface
        public boolean openFile(final String uriText) {
            try {
                Uri uri = Uri.parse(uriText);
                String mime = getContentResolver().getType(uri);
                Intent view = new Intent(Intent.ACTION_VIEW);
                view.setDataAndType(uri, mime != null ? mime : "*/*");
                view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                final Intent chooser = Intent.createChooser(view, "Abrir com");
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            startActivity(chooser);
                        } catch (Exception ignored) {
                        }
                    }
                });
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void openHomeSettings() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
                    } catch (Exception e) {
                        startActivity(new Intent(Settings.ACTION_SETTINGS));
                    }
                }
            });
        }

        @JavascriptInterface
        public void openSystemSettings() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(new Intent(Settings.ACTION_SETTINGS));
                    } catch (Exception ignored) {
                    }
                }
            });
        }
    }
}
